/* B34N5 tracer — no-op service worker. No network, no keys. */
