# B34N5 Transaction Tracer (download)

Read-only XRPL **Mainnet** transaction map. Paste an r-address or a transaction hash to watch a ping travel from sender to receiver on a rotatable 3D globe. Drag to tumble a full 360°, pinch or scroll to zoom in through the arcs, and tap any node for account details.

This tool:

- Never asks for keys, seeds, logins or personal info
- Never signs or sends transactions
- We don't collect or store data for ourselves
- Watched addresses are saved only in your browser, on this device
- Transaction data is read live from public XRPL websockets (`xrplcluster.com`, `s1.ripple.com`, `s2.ripple.com`)
- No analytics or tracking scripts

Tips, if you choose to send one, go to a public r-address shown in the app. You pay from your own wallet. The tracer does not connect to it.

## Web version

Unzip `xrpl-tracer-web-v0.1.zip` and open `index.html` in a browser. A local file open is enough; if a browser blocks the websocket, serve the folder instead:

```bash
python3 -m http.server 8877 --bind 127.0.0.1 --directory .
```

Then open http://127.0.0.1:8877/

## Chrome or Edge extension (unpacked)

1. Unzip `xrpl-tracer-extension-v0.1.zip` to a folder you can keep.
2. In Chrome or Edge, open `chrome://extensions` (or `edge://extensions`).
3. Turn on **Developer mode**.
4. Click **Load unpacked** and choose the unzipped folder (the one that contains `manifest.json`).
5. Pin the extension if you like, then click the icon to open the tracer.

This is a Manifest V3 extension with no extra permissions. It is not listed on the Chrome Web Store yet. Only install it from a copy you got from B34N5.

## Safety

If anything ever asks for a seed, secret, or to "connect a wallet," close it — that is not this tool.
