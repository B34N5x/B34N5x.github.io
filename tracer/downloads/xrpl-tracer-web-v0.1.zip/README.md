# B34N5 Transaction Tracer (isolated preview)

Read-only XRPL **Mainnet** HUD. Paste an r-address or a transaction hash to watch a glowing ping travel from sender to receiver on a rotatable, zoomable 3D globe. Drag to tumble a full 360°, pinch or scroll to zoom in through the arcs, and tap any node for account details.

This folder is a standalone preview. It is **not** wired into b34n5.xyz or The Lobby.

- Never asks for keys, seeds, logins or personal info
- Never signs or sends transactions
- We don't collect or store data for ourselves
- Watched addresses are saved only in the browser (`localStorage` key `b34n5.tracer.watches` on this device)
- Transaction data is read live from public XRPL websockets (`xrplcluster.com`, `s1.ripple.com`, `s2.ripple.com`)
- No analytics or tracking scripts
- Issued tokens from issuers not on this tool's known list are labelled unverified — not a scam call; xrp-ledger.toml is not checked

## Open locally

```bash
python3 -m http.server 8877 --bind 127.0.0.1 --directory /workspace/xrpl-tracer
```

Then open http://127.0.0.1:8877/

A local server from this build may already be running on that port.

## Cloudflare Pages preview (not production)

- https://preview.xrpl-tracer-preview.pages.dev
- Latest unique deploy: https://6a713796.xrpl-tracer-preview.pages.dev

These are preview-branch URLs only. Nothing was deployed to the project's production URL or to b34n5.xyz.

## Example hash baked into "Try an example"

A real validated mainnet Payment captured during the preview build (894.86005 XRP):
`BF2B0B95C54E4FE60829D77ED71F245BDCE9A4977069C9C2A14F6FBAE265B02D`


## Promo (not posted)

- Clip: `promo/tracer-snippet.mp4`
- Draft X post: `promo/post.txt` (do not publish until Beans approves)


## Tips

A small XRP-style coin in the header opens a public tips address (`r3vRGJPqasAJgjyU98xxL8tvx2WiEni41f`) plus a QR you can scan in your own wallet. A little **?** beside the coin shows a short memo. The brand mark links to [B34N5x on X](https://x.com/B34N5XRP). This tool never connects a wallet.

## Downloads

- `dist/xrpl-tracer-web-v0.1.zip` — unzip and open `index.html`
- `dist/xrpl-tracer-extension-v0.1.zip` — Chrome/Edge Manifest V3, load unpacked (see `dist/README.md`)
